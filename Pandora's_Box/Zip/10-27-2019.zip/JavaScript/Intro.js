function Start() {
Title.style.display = "block"
Options_Panel.style.display = "inline-block"
Health_Panel.style.display = "block"
Currency_Panel.style.display = "inline-block"
Stat_Panel.style.display = "inline-block"
Start_Button.style.display = "none"
Player_Name.innerHTML = "Player";
}
