function Start() {
title.style.display = "block"
option_panel.style.display = "inline-block"
health_panel.style.display = "block"
currency_panel.style.display = "inline-block"
stat_panel .style.display = "inline-block"
start_button.style.display = "none"
Player_Name.innerHTML = "Player";
}
