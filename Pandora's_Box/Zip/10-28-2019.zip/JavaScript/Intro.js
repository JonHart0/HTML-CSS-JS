function Start() {
Options_Panel.style.display = "inline-block"
Health_Panel.style.display = "block"
Currency_Panel.style.display = "inline-block"
Stat_Panel.style.display = "inline-block"
Start_Button.style.display = "none"
Player_Name.innerHTML = "Player";

Inventory_Panel.style.display = "none"
Store_Panel.style.display = "none"
Explore_Panel.style.display = "none"
Debug_Panel.style.display = "none"
}
Start();
